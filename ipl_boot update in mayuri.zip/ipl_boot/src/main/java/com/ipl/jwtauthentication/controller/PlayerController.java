package com.ipl.jwtauthentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.security.services.PlayerService;


@RestController
public class PlayerController {
	
	@Autowired(required=true)
	PlayerService service;
	
	@GetMapping({"/players"})
	public Iterable<Player> findAll(){
		return service.findAll();
	}
	
	/*
	 * @GetMapping("/player/{pid}") public Player findById(@PathVariable int
	 * playerId) { return service.findById(playerId); }
	 * 
	 * @PostMapping("/player/save") public String save(@RequestBody Player player) {
	 * return service.save(player); }
	 * 
	 * @PutMapping(
	 * "/player/update/{playerId}/{selectedTeam}/{strikeRate}/{average}/{playerRank}/{experience}")
	 * public String update(@PathVariable int playerId,@PathVariable String
	 * selectedTeam,@PathVariable double strikeRate,@PathVariable double
	 * average,@PathVariable int playerRank,@PathVariable int experience) { return
	 * service.update(playerId,selectedTeam,
	 * strikeRate,average,playerRank,experience); }
	 * 
	 * @DeleteMapping("/player/delete/{playerId}") public String
	 * deleteById(@PathVariable int playerId) { return service.deleteById(playerId);
	 * }
	 */

}
