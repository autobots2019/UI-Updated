package com.ipl.jwtauthentication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ipl.jwtauthentication.model.Player;


@Repository
public interface IPlayerRepository extends JpaRepository<Player, Integer> {
	
	List<Player> findAll();
	
}
