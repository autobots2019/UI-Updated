package com.ipl.jwtauthentication.security.services;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ipl.jwtauthentication.model.Player;
import com.ipl.jwtauthentication.repository.IPlayerRepository;



@Service
 public class PlayerService {
	
	@Autowired
	private IPlayerRepository repository;
	
	public Iterable<Player> findAll(){
		return repository.findAll();
	}
	
	/*
	 * public Player findById(int playerId) {
	 * 
	 * return repository.findById( playerId).get(); } public String deleteById(int
	 * playerId) { repository.deleteById(playerId); return "Deleted"; } public
	 * String save(Player entity) { Player newPlayer=repository.save(entity); return
	 * "Saved"+newPlayer; } public String update(int playerId,String
	 * selectedTeam,double strikeRate,double average,int playerRank,int experience)
	 * { Player player=findById(playerId);
	 * 
	 * player.setSelectedTeam( selectedTeam); player.setStrikeRate(strikeRate);
	 * player.setAverage(average); player.setPlayerRank(playerRank);
	 * player.setExperience(experience); repository.save(player); return
	 * "Updated"+player; }
	 */
}
