import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayerregisterComponent } from './playerregister.component';

describe('PlayerregisterComponent', () => {
  let component: PlayerregisterComponent;
  let fixture: ComponentFixture<PlayerregisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlayerregisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlayerregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
